/* Local demonstration only. No PLC/serial/network I/O. 100 ms HMI refresh.
   Sequence ages and RUN remain wall-clock seconds, independent of refresh rate. */
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
/* The local block callback ABI is the same as the installed macro.h GetMem/SetMem.
   Keep this small adapter self-contained for the older ECP-07 ARM compiler. */
typedef int (*MacroOper)(const char*,void*,int*);
const char *macroID="8f9c30cb51514f9d84d6600098919142";
static int _LocalBlock(const char *operation,void *data,const char *mid,const char *aid,int offset,int bytes,MacroOper callback) {
 int error=0;int p[5]={(int)data,(int)mid,(int)aid,offset,bytes};
 return callback(operation,p,&error);
}
#define GetMem(data,mid,aid,offset,bytes) _LocalBlock("GetMem",data,mid,aid,offset,bytes,macroOper)
#define SetMem(data,mid,aid,offset,bytes) _LocalBlock("SetMem",data,mid,aid,offset,bytes,macroOper)
#define MacroMain() _macro_main(MacroOper macroOper)

enum { MAGIC=0, ST=1, AGE=2, RUN=3, O2=4, PT=5, H2=6, TEMP=7,
 GATE=8, BLOWER=9, VALVE=10, MAKEUP=11, POWDER=12, LINK=13, ESTOP=14,
 GAS=15, FILTER=16, NOTICE=17, FILTERSEL=18, LOGCOUNT=19, SESSION=20,
 MATERIAL=21, FAULT=22, CALSTEP=23, CALRESULT=24,
 SAVED=30, DRAFT=40, DISPLAY=100, RING=300 };
enum { START=0, STOP=1, CLEAN=2, FAN=3, VALVETOGGLE=4, MINUS=5, PLUS=6,
 CLOSEGATE=7, MAKEAUTO=8, MAKEMANUAL=9, SAVECFG=10, CANCELCFG=11,
 GASCHANGE=12, MATERIALCHANGE=13, CALOPEN=14, CALNEXT=15, CALCLOSE=16,
 ALL=17, WARN=18, ALARM=19, EXPORT=20, RESET=21, DEMOFAULT=22,
 ACK=23, EMERGENCY=24 };
enum { READY=0, CHECK=1, FLOW=2, LOAD=3, PURGE=4, DONE=5, CLEANING=6,
 TRIPPED=7, MANUAL=8 };
/* Events: startup/start/flow/loading/stop/purge/end/clean etc.; sources 0 system,1 operator,2 printer. */
static void event(unsigned short *w,int code,int severity,int source) {
 int i; for(i=23;i>0;i--) memcpy(w+RING+i*4,w+RING+(i-1)*4,8);
 w[RING]=w[SESSION];w[RING+1]=code;w[RING+2]=severity;w[RING+3]=source;
 if(w[LOGCOUNT]<24)w[LOGCOUNT]++;
}
static void state(unsigned short *w,int value) {w[ST]=value;w[AGE]=0;}
static int healthy(unsigned short *w) {
 return w[ESTOP] && w[LINK] && w[POWDER] && !w[FAULT] && w[O2]<w[SAVED+3] && w[TEMP]<60;
}
static int cleanpermit(unsigned short *w) {return w[ESTOP]&&!w[BLOWER]&&!w[VALVE]&&!w[GATE]&&!w[FAULT]&&w[ST]!=CLEANING;}
static void trip(unsigned short *w,int code) {
 w[GATE]=0;w[BLOWER]=0;w[VALVE]=0;w[FILTER]=0;state(w,TRIPPED);w[NOTICE]=code;event(w,19,2,0);
}
static void logic(unsigned short *w,unsigned char *b,int tick) {
 int i,j,row,permit;char text[16];
 if(w[MAGIC]!=17341) {
  memset(w,0,1024*sizeof(short));memset(b,0,160);
  w[MAGIC]=17341;w[O2]=18;w[H2]=32;w[TEMP]=26;
  w[POWDER]=w[LINK]=w[ESTOP]=1;
  w[SAVED]=0;w[SAVED+1]=35;w[SAVED+2]=5;w[SAVED+3]=50;
  w[SAVED+4]=30;w[SAVED+5]=30;w[SAVED+6]=0;
  memcpy(w+DRAFT,w+SAVED,7*sizeof(short));event(w,1,0,0);
 }
 if(tick){w[SESSION]++;w[AGE]++;}
 if(b[START]) {
  if(healthy(w)&&(w[ST]==READY||w[ST]==DONE)&&!w[BLOWER]) {
   w[RUN]=0;w[NOTICE]=0;w[VALVE]=1;state(w,CHECK);event(w,2,0,1);
  }else {w[NOTICE]=1;event(w,18,1,1);}
 }
 if(b[STOP]) {
  w[GATE]=0;
  if(w[BLOWER]&&w[ESTOP]) {if(w[ST]!=PURGE){state(w,PURGE);event(w,5,0,1);event(w,6,0,0);}}
  else {w[BLOWER]=0;w[VALVE]=0;w[FILTER]=0;state(w,READY);w[NOTICE]=0;event(w,5,0,1);}
 }
 if(b[FAN]) {
  if(w[ST]==MANUAL&&w[BLOWER]) {w[GATE]=0;state(w,PURGE);event(w,5,0,1);}
  else if(healthy(w)&&(w[ST]==READY||w[ST]==DONE)&&w[VALVE]) {w[BLOWER]=1;w[RUN]=0;state(w,MANUAL);w[NOTICE]=0;event(w,10,0,1);}
  else {w[NOTICE]=2;event(w,18,1,1);}
 }
 if(b[VALVETOGGLE]) {
  if(!w[BLOWER]&&w[ST]!=CLEANING) {w[VALVE]=!w[VALVE];w[NOTICE]=0;event(w,w[VALVE]?12:13,0,1);}
  else {w[NOTICE]=3;event(w,18,1,1);}
 }
 if(b[MINUS]&&w[ST]==MANUAL)w[GATE]=w[GATE]>=5?w[GATE]-5:0;
 if(b[PLUS]) {
  if(w[ST]==MANUAL&&w[BLOWER]&&w[AGE]>=3&&w[PT]>=w[SAVED+2]&&healthy(w)&&w[VALVE]) {
   if(w[GATE]<100)w[GATE]+=5;event(w,11,0,1);w[NOTICE]=0;
  } else {w[NOTICE]=4;event(w,18,1,1);}
 }
 if(b[CLOSEGATE])w[GATE]=0;
 if(b[MAKEAUTO])w[MAKEUP]=0;
 if(b[MAKEMANUAL])w[MAKEUP]=1;
 if(b[CLEAN]) {
  if(cleanpermit(w)) {state(w,CLEANING);w[FILTER]=1;w[NOTICE]=0;event(w,8,0,1);}
  else {w[NOTICE]=5;event(w,18,1,1);}
 }
 if(b[GASCHANGE]) {if(w[DRAFT+6]){w[DRAFT]=0;w[NOTICE]=6;}else w[DRAFT]=!w[DRAFT];}
 if(b[MATERIALCHANGE]) {w[DRAFT+6]=!w[DRAFT+6];if(w[DRAFT+6])w[DRAFT]=0;}
 if(b[SAVECFG]) {
  if(!w[BLOWER]&&w[ST]!=CLEANING) {
   if(w[DRAFT+1]>100)w[DRAFT+1]=100;
   if(w[DRAFT+2]<1)w[DRAFT+2]=1;if(w[DRAFT+2]>20)w[DRAFT+2]=20;
   if(w[DRAFT+3]<1)w[DRAFT+3]=1;if(w[DRAFT+3]>50)w[DRAFT+3]=50;
   if(w[DRAFT+4]<10)w[DRAFT+4]=10;if(w[DRAFT+4]>50)w[DRAFT+4]=50;
   if(w[DRAFT+5]<1)w[DRAFT+5]=1;if(w[DRAFT+5]>30)w[DRAFT+5]=30;
   if(w[DRAFT+6])w[DRAFT]=0;
   memcpy(w+SAVED,w+DRAFT,7*sizeof(short));w[NOTICE]=7;event(w,14,0,1);
  }else w[NOTICE]=8;
 }
 if(b[CANCELCFG]){memcpy(w+DRAFT,w+SAVED,7*sizeof(short));w[NOTICE]=9;}
 if(b[CALOPEN]){w[CALSTEP]=1;w[CALRESULT]=0;}
 if(b[CALNEXT]&&w[CALSTEP]>0) {
  if(w[BLOWER])w[NOTICE]=8;
  else if(w[CALSTEP]<4)w[CALSTEP]++;
  else if(w[CALSTEP]==4) {w[CALRESULT]=1;w[CALSTEP]=5;event(w,15,0,1);}
 }
 if(b[CALCLOSE])w[CALSTEP]=0;
 if(b[ALL])w[FILTERSEL]=0;if(b[WARN])w[FILTERSEL]=1;if(b[ALARM])w[FILTERSEL]=2;
 if(b[DEMOFAULT]) {w[FAULT]=!w[FAULT];if(w[FAULT])trip(w,10);else {state(w,READY);w[NOTICE]=11;event(w,20,0,1);}}
 if(b[EMERGENCY]) {w[ESTOP]=!w[ESTOP];if(!w[ESTOP])trip(w,12);else {state(w,READY);w[NOTICE]=11;event(w,20,0,1);}}
 if(b[ACK]){w[NOTICE]=0;event(w,21,0,1);}
 if(b[RESET]&&!w[BLOWER]) {w[MAGIC]=0;return;}
 if((w[BLOWER]||w[ST]==CHECK)&&!healthy(w))trip(w,w[FAULT]?10:12);
 if(tick) {
  if(w[BLOWER]){w[RUN]++;if(w[PT]<w[SAVED+2]+5)w[PT]+=2;w[TEMP]=30+(w[RUN]%12);}
  else {if(w[PT]>0)w[PT]--;if(w[TEMP]>26)w[TEMP]--;}
  w[O2]=w[FAULT]?85:(w[BLOWER]?17+w[RUN]%3:18);
  w[H2]=w[BLOWER]?31+w[RUN]%4:32;
  switch(w[ST]) {
   case CHECK:if(w[AGE]>=2){w[BLOWER]=1;state(w,FLOW);event(w,3,0,0);}break;
   case FLOW:if(w[AGE]>=4&&w[PT]>=w[SAVED+2]){w[GATE]=w[SAVED+1];state(w,LOAD);event(w,4,0,0);}break;
   case LOAD:if(w[AGE]>=45||w[RUN]>=w[SAVED+5]*60){w[GATE]=0;state(w,PURGE);event(w,22,0,2);event(w,6,0,0);}break;
   case PURGE:if(w[AGE]>=5){w[BLOWER]=0;w[VALVE]=0;state(w,DONE);event(w,7,0,0);}break;
   case CLEANING:if(w[AGE]>=3){w[FILTER]=0;state(w,READY);event(w,9,0,0);}break;
   case MANUAL:if(w[RUN]>=w[SAVED+5]*60){w[GATE]=0;state(w,PURGE);event(w,23,1,0);}break;
  }
 }
 /* Display seconds as MM:SS in ASCII, independent of panel text encoding. */
 memset(w+60,0,8);sprintf((char*)(w+60),"%02u:%02u",w[RUN]/60,w[RUN]%60);
 memset(w+65,0,8);sprintf((char*)(w+65),"%02u:00",w[SAVED+5]);
 /* Header date and three explicit progress states: pending/active/completed. */
 {time_t now=time(0);struct tm *tm=localtime(&now);
  memset(w+72,0,12);if(tm)strftime((char*)(w+72),12,"%d.%m.%Y",tm);
 }
 for(i=0;i<4;i++) {
  w[80+i]=w[ST]==DONE?2:((w[ST]>=CHECK&&w[ST]<=PURGE)?(w[ST]==i+1?1:(w[ST]>i+1?2:0)):0);
 }
 /* Native bit indicator states and command permits. */
 memset(b,0,160);
 b[100]=w[BLOWER];b[101]=w[VALVE];b[102]=w[MAKEUP];b[103]=w[FILTER];
 b[104]=w[ST]==LOAD;b[105]=w[ST]==PURGE;b[106]=w[ESTOP];b[107]=w[FAULT];
 b[108]=healthy(w)&&(w[ST]==READY||w[ST]==DONE)&&!w[BLOWER];b[109]=cleanpermit(w);
 b[110]=w[GATE]>0;b[111]=w[LINK];b[112]=w[POWDER];b[113]=!w[BLOWER]&&w[ST]!=CLEANING;
 for(i=0;i<4;i++)b[120+i]=w[80+i]==2;
 b[125]=w[DRAFT];b[126]=w[DRAFT+6];b[127]=w[CALRESULT];
 b[130]=w[FILTERSEL]==0;b[131]=w[FILTERSEL]==1;b[132]=w[FILTERSEL]==2;
 b[133]=w[NOTICE]==7;b[134]=w[NOTICE]==9;
 w[70]=w[ST]==CLEANING?2:(b[109]?1:0);
 /* Journal: 24-entry ring, filtered six-row page. codes in native word indicators. */
 row=0;for(i=0;i<w[LOGCOUNT]&&row<6;i++) {
  j=RING+i*4;if(w[FILTERSEL]&&w[j+2]!=w[FILTERSEL])continue;
  memset(w+DISPLAY+row*12,0,24);
  sprintf((char*)(w+DISPLAY+row*12),"%02u:%02u:%02u",w[j]/3600,(w[j]/60)%60,w[j]%60);
  w[DISPLAY+row*12+5]=w[j+1];w[DISPLAY+row*12+6]=w[j+3]+1;row++;
 }
 while(row<6){memset(w+DISPLAY+row*12,0,24);row++;}
}

#ifndef DEMO_TEST
static void sample_values(unsigned short *w,int slot) {
 static const int ripple[10]={0,1,2,3,2,1,0,-1,-2,-1};
 /* O2 is displayed in hundredths of a percent; other sensors retain their
    existing integer precision and can legitimately repeat sampled values. */
 w[O2]=w[FAULT]?85:(w[BLOWER]?18+ripple[slot]:18);
 w[H2]=w[BLOWER]?32+ripple[slot]/2:32;
}
static void elapsed_tenths(unsigned short *w,int slot) {
 memset(w+60,0,8);
 sprintf((char*)(w+60),"%02u:%02u.%d",w[RUN]/60,w[RUN]%60,w[BLOWER]?slot:0);
}
int MacroMain() {
 unsigned short w[1024];unsigned char b[160];struct timeval tv;
 unsigned long seconds,previous;int clock_valid,tick,refresh,slot,i;
 if(!GetMem(w,@DEMO_WORDS@,0,sizeof(w)))return 0;
 memset(b,0,sizeof(b));
 /* Match macro.h GetBit/SetBit: one byte at an explicit bit-register offset.
    Acknowledge only a received command; never overwrite the whole command block
    when publishing indicator states, as that can erase a newly queued press. */
 for(i=0;i<=EMERGENCY;i++) {
  unsigned char zero=0;
  if(!GetMem(b+i,@DEMO_BITS@,i,1))return 0;
  b[i]=!!b[i];
  if(b[i]&&!SetMem(&zero,@DEMO_BITS@,i,1))return 0;
 }
 gettimeofday(&tv,0);slot=tv.tv_usec/100000;seconds=(unsigned long)tv.tv_sec;
 /* Macro-local static data may be recreated on every HMI invocation.
    Keep the shared clock in reserved local words, not in the macro image.
    84=clock format marker; 85/86=last seconds low/high; 87=last 100 ms slot. */
 clock_valid=w[MAGIC]==17341&&w[84]==21324;
 previous=(unsigned long)w[85]|((unsigned long)w[86]<<16);
 tick=clock_valid&&seconds>previous;
 refresh=!clock_valid||seconds!=previous||slot!=w[87];
 /* CSV export goes to the runtime's writable working directory. Check actual write. */
 if(b[EXPORT]&&w[MAGIC]==17341) {
  FILE *f=fopen("SLM_demo_events.csv","wb");int i,j,ok=1;
  if(f){fprintf(f,"session_seconds,event_code,severity,source\r\n");
   for(i=w[LOGCOUNT]-1;i>=0;i--){j=RING+i*4;
    if(fprintf(f,"%u,%u,%u,%u\r\n",w[j],w[j+1],w[j+2],w[j+3])<0)ok=0;
   }if(fclose(f))ok=0;
  }else ok=0;
  w[NOTICE]=ok?13:14;event(w,ok?16:17,ok?0:1,1);
 }
 logic(w,b,tick);
 if(refresh)sample_values(w,slot);
 elapsed_tenths(w,slot);
 /* logic() can initialise/clear the block, so publish the clock afterwards.
    A backwards wall-clock change rebases without adding a spurious second. */
 w[84]=21324;w[85]=(unsigned short)seconds;w[86]=(unsigned short)(seconds>>16);w[87]=(unsigned short)slot;
 SetMem(w,@DEMO_WORDS@,0,sizeof(w));
 for(i=100;i<=134;i++)SetMem(b+i,@DEMO_BITS@,i,1);
 return 0;
}
#endif
